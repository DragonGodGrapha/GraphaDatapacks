dyes=['orange','magenta','light_blue','yellow','lime',
      'pink', 'gray', 'light_gray', 'cyan', 'purple',
      'green', 'red', 'black', 'brown', 'blue', 'white']

file=open("convert.mcfunction",'w')
for i in dyes:
    file.write(f'execute as @e[type=item,nbt={{Item:{{id:"minecraft:{i}_concrete_powder"}}}}] at @s if block ~ ~ ~ minecraft:cauldron unless block ~ ~ ~ minecraft:cauldron[level=0] run data merge entity @s {{Item:{{id:"minecraft:{i}_concrete"}}}}\r')
               
file.close()