import os

dyes=['orange','magenta','light_blue','yellow','lime',
      'pink', 'gray', 'light_gray', 'cyan', 'purple',
      'green', 'red', 'black', 'brown', 'blue', 'white']


recipes=['concrete_powder','glazed_terracotta',
         'stained_glass', 'stained_glass_pane',
         'terracotta', 'wool', 'candle']

beds=['bed']

clean = {'stained_glass':'glass',
         'stained_glass_pane':'glass_pane',
         'terracotta':'terracotta',
         'candle':'candle'}

def makeandmove(path):
    if not os.path.exists(path):
        os.makedirs(path)
    os.chdir(path)
    
makeandmove('data')
makeandmove('universal_dyeing')


for folder in ['tags','recipes','advancements']:
    if not os.path.exists(folder):
        os.makedirs(folder)

makeandmove('tags/items')


##Tag groups
for item in recipes+beds:
    with open(f"{item}.json",'w') as file:
        file.write('{\r    "values": [\r')
        if item in clean:
            file.write(f'        "minecraft:{clean[item]}",\r')
        for color in dyes:
            file.write(f'        "minecraft:{color}_{item}"{"," if color!="white" else ""}\r')
        file.write('    ]\r}')
        
        
with open("dyes.json",'w') as file:
    file.write('{\r    "values": [\r')
    for color in dyes:
        file.write(f'        "minecraft:{color}_dye"{"," if color!="white" else ""}\r')
    file.write('    ]\r}')

##Advancements
os.chdir('../..')
makeandmove('advancements/recipes/building_blocks/universal_dyeing')

for item in recipes+beds:
    with open(f'{item}.json','w') as file:
        file.write('''{\r    "parent": "minecraft:recipes/root",\r    "criteria": {\r        "has_block": {
\r            "trigger": "minecraft:inventory_changed",\r            "conditions": {\r                "items": [\r                    {''')
        file.write(f'                        "tag": "universal_dyeing:{item}"\r')
        file.write('''                    }\r                ]\r            }\r        },\r        "has_dye": {r\            "trigger": "minecraft:inventory_changed",\r
            "conditions": {
                "items": [\r                    {\r                        "tag": "universal_dyeing:dyes"\r                    }\r                ]\r            }\r
        }\r    },\r    "requirements": [\r        [\r            "has_block"\r        ],\r        [\r            "has_dye"\r        ]\r    ],\r    "rewards": {\r
        "recipes": [\r''')
        for color in dyes:
            file.write(f'            "universal_dyeing:{color}_{item}"{"," if color!="white" else ""}\r')
        file.write('        ]\r    }\r}')
        
##Recipes
        
os.chdir('../../../..')
os.chdir('recipes')

for item in recipes:
    makeandmove(item)
    for color in dyes:
        for n in range(1,9):
            with open(f'{color}_{item}_{n}.json','w') as file:
                file.write('{\r')
                file.write('    "type": "crafting_shapeless",\r')
                file.write('    "result": {\r')
                file.write(f'        "item": "minecraft:{color}_{item}",\r')
                file.write(f'        "count": {n}\r')
                file.write('    },\r')
                file.write(f'    "group": "universal_dyeing_{item}",\r')
                file.write('    "ingredients": [\r')
                
                for c in range(0,n):
                    file.write('        {\r')
                    file.write(f'            "tag": "universal_dyeing:{item}"\r')
                    file.write('        },\r')
                
                file.write('        {\r')
                file.write(f'            "item": "minecraft:{color}_dye"\r')
                file.write('        }\r')
                file.write('    ]\r')
                file.write('}')
                
    if item in clean:
        for n in range(1,9):
            with open(f'{clean[item]}_{n}.json','w') as file:
                file.write('{\r')
                file.write('    "type": "crafting_shapeless",\r')
                file.write('    "result": {\r')
                file.write(f'        "item": "minecraft:{clean[item]}",\r')
                file.write(f'        "count": {n}\r')
                file.write('    },\r')
                file.write(f'    "group": "universal_dyeing_{item}",\r')
                file.write('    "ingredients": [\r')
                    
                for c in range(0,n):
                    file.write('        {\r')
                    file.write(f'            "tag": "universal_dyeing:{item}"\r')
                    file.write('        },\r')
                    
                file.write('        {\r')
                file.write('            "item": "minecraft:ice"\r')
                file.write('        }\r')
                file.write('    ]\r')
                file.write('}')
    os.chdir('..')
makeandmove('bed')

#beds
for i in dyes:
    for j in beds:
        
        with open(f"{i}_{j}.json",'w') as file:
            file.write('{\r')
            file.write('    "type": "crafting_shapeless",\r')
            file.write('    "result": {\r')
            file.write(f'        "item": "minecraft:{i}_{j}",\r')
            file.write('        "count": 1\r')
            file.write('    },\r')
            file.write(f'    "group": "universal_dyeing_{j}",\r')
            file.write('    "ingredients": [\r')
            file.write('        {\r')
            file.write('            "tag": "universal_dyeing:bed"\r')
            file.write('        },\r')
            file.write('        {\r')
            file.write(f'            "item": "minecraft:{i}_dye"\r')
            file.write('        },\r')
            file.write('        {\r')
            file.write(f'            "item": "minecraft:{i}_dye"\r')
            file.write('        },\r')
            file.write('        {\r')
            file.write(f'            "item": "minecraft:{i}_dye"\r')
            file.write('        }\r')
            file.write('    ]\r')
            file.write('}')

           
                