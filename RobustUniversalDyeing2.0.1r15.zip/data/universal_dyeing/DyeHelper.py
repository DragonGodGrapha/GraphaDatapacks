dyes=['orange','magenta','light_blue','yellow','lime',
      'pink', 'gray', 'light_gray', 'cyan', 'purple',
      'green', 'red', 'black', 'brown', 'blue', 'white']


recipes=['concrete_powder','glazed_terracotta',
         'stained_glass', 'stained_glass_pane',
         'terracotta', 'wool']

beds=['bed']

clean = [['stained_glass','glass'],
         ['stained_glass_pane','glass_pane'],
         ['terracotta','terracotta']]

#start main

for i in dyes:
    for j in recipes:
        for n in range(1,9):
            file=open(f"recipes//{i}_{j}_{n}.json",'w')
            file.write('{\r')
            file.write('    "type": "crafting_shapeless",\r')
            file.write('    "result": {\r')
            file.write(f'        "item": "minecraft:{i}_{j}",\r')
            file.write(f'        "count": {n}\r')
            file.write('    },\r')
            file.write(f'    "group": "universal_dyeing_{j}",\r')
            file.write('    "ingredients": [\r')
            
            for c in range(0,n):
                file.write('        {\r')
                file.write(f'            "tag": "universal_dyeing:{j}"\r')
                file.write('        },\r')
            
            file.write('        {\r')
            file.write(f'            "item": "minecraft:{i}_dye"\r')
            file.write('        }\r')
            file.write('    ]\r')
            file.write('}')
            file.close()
            
#beds
for i in dyes:
    for j in beds:
        
        file=open(f"recipes//{i}_{j}.json",'w')
        file.write('{\r')
        file.write('    "type": "crafting_shapeless",\r')
        file.write('    "result": {\r')
        file.write(f'        "item": "minecraft:{i}_{j}",\r')
        file.write('        "count": 1\r')
        file.write('    },\r')
        file.write(f'    "group": "universal_dyeing_{j}",\r')
        file.write('    "ingredients": [\r')
        file.write('        {\r')
        file.write('            "tag": "universal_dyeing:bed"\r')
        file.write('        },\r')
        file.write('        {\r')
        file.write(f'            "item": "minecraft:{i}_dye"\r')
        file.write('        },\r')
        file.write('        {\r')
        file.write(f'            "item": "minecraft:{i}_dye"\r')
        file.write('        },\r')
        file.write('        {\r')
        file.write(f'            "item": "minecraft:{i}_dye"\r')
        file.write('        }\r')
        file.write('    ]\r')
        file.write('}')
        file.close()
        
for j in clean:
    for n in range(1,9):
        file=open(f"recipes//{j[1]}_{n}.json",'w')
        file.write('{\r')
        file.write('    "type": "crafting_shapeless",\r')
        file.write('    "result": {\r')
        file.write(f'        "item": "minecraft:{j[1]}",\r')
        file.write(f'        "count": {n}\r')
        file.write('    },\r')
        file.write(f'    "group": "universal_dyeing_{j[0]}",\r')
        file.write('    "ingredients": [\r')
            
        for c in range(0,n):
            file.write('        {\r')
            file.write(f'            "tag": "universal_dyeing:{j[0]}"\r')
            file.write('        },\r')
            
        file.write('        {\r')
        file.write('            "item": "minecraft:ice"\r')
        file.write('        }\r')
        file.write('    ]\r')
        file.write('}')
        file.close()